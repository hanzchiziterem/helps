import React from "react";

class BookList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      books: [
        { id: 1, name: "Zero to One", author: "Peter Thiel" },
        { id: 2, name: "Monk who sold his Ferrari", author: "Robin Sharma" },
        { id: 3, name: "Wings of Fire", author: "A.P.J. Abdul Kalam" },
      ],
      selectedBooks: [],
      error: false,
    };

    this.handleSelectedBooks = this.handleSelectedBooks.bind(this);
    this._renderBook = this._renderBook.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this._renderError = this._renderError.bind(this);
  }

  _renderError() {
    if (this.state.error) {
      return (
        <div
          style={{
            width: "50%",
            padding: "5px 10px 10px 10px",
            backgroundColor: "#ffdbdb",
            color: "#ec2d1f",
            border: "1px solid #ffdbdb",
            borderRadius: 5,
          }}
        >
          {this.state.error}
        </div>
      );
    }
  }

  handleSelectedBooks(event) {
    var selectedBooks = this.state.selectedBooks;
    var index = selectedBooks.indexOf(event.target.value);
    if (event.target.checked) {
      if (index === -1) selectedBooks.push(event.target.value);
    } else {
      selectedBooks.splice(index, 1);
    }
    this.setState({ selectedBooks: selectedBooks });
  }

  handleSubmit(e) {
    e.preventDefault();
    if (this.state.selectedBooks.length === 0) {
      this.setState({ error: "Please choose at least one book to continue" });
    } else {
        // console.log(this.state.selectedBooks.length);
      this.setState({ error: false });      
    }
  }

  _renderBook(book) {
    return (
      <div style={{ paddingBottom: 20 }} className="checkbox" key={book.id}>
        <label htmlFor="">
          <input
            type="checkbox"
            onChange={this.handleSelectedBooks}
            value={book.name}
          />{" "}
          {book.name} --- {book.author}
        </label>
      </div>
    );
  }

  render() {
    var errMsg = this._renderError();
    return (
      <div>
        <h3>Choose from wide variety of books avaliable in our store</h3>
        {errMsg}
        <form style={{ paddingTop: 20 }} onSubmit={this.handleSubmit}>
          {this.state.books.map((book) => {
            return this._renderBook(book);
          })}
          <input
            style={{
              width: "30",
              padding: "5px 10px 5px 10px",
              backgroundColor: "#61dafb",
              color: "#fff",
              border: "1px solid #61dafb",
              borderRadius: 5,
            }}
            type="submit"
            value="Submit"
            className="btn btn-success"
          />
        </form>
      </div>
    );
  }
}

export default BookList;
