import React, { Component } from "react";
class ShippingDetails extends Component {
    constructor(){
        super();

        this.state = {
            fullName: '',
            contactNumber: '',
            shippingAddress: '',
            error: false
        }
    }

    _renderError() {
        if (this.state.error) {
          return (
            <div
              style={{
                width: "50%",
                padding: "5px 10px 10px 10px",
                backgroundColor: "#ffdbdb",
                color: "#ec2d1f",
                border: "1px solid #ffdbdb",
                borderRadius: 5,
              }}
            >
              {this.state.error}
            </div>
          );
        }
      }
    

      _validateInput(){
        if (this.state.fullName === '') {
            this.setState({error: 'Please Enter your full name'});
        } else if(this.state.contactNumber === '') {
            this.setState({error: 'Please Enter Contact Number'});
        } else if (this.state.shippingAddress === '') {
            this.setState({error: 'Please Enter Shipping Address'});
        } else {
            this.setState({error: false});
            return true
        }
      }

      handleSubmit(e) {
        e.preventDefault();

        var formData = {
            fullName: this.state.fullName,
            contactNumber: this.state.contactNumber,
            shippingAddress: this.state.shippingAddress
        }

        if (this._validateInput()) {
            this.props.updateFormData(formData);
        }
      }

      handleChange(e, attr){
        var newState = this.state;
        newState[attr] = e.target.value;
        this.setState(newState);
        console.log(this.state);
      }
     render() {
        var errMsg = this._renderError();

        return(
            	<div style={{width: 200}}>
                    {errMsg}
                    <form onSubmit={this.handleSubmit}>
                        <div className="form-group">
                            <input type="text" placeholder="Full name" value={this.state.fullName} onChange={e=>this.handleChange(e, 'fullName')} />
                        </div>
                        <div className="form-group">
                            <input type="text" placeholder="Contact Number" value={this.state.contactNumber} onChange={e=>this.handleChange(e, 'contactNumber')} />
                        </div>
                        <div className="form-group">
                            <input type="text" placeholder="Shipping Address" value={this.state.shippingAddress} onChange={e=>this.handleChange(e, 'shippingAddress')} />
                        </div>
                        <div className="form-group">
                            <button type="submit">Submit</button>
                            </div>
                    </form>
                </div>
        );
     } 
}


export default ShippingDetails;