import React, { Component } from "react";

class DeliveryDetails extends Component {
    constructor() {
        super();
        
        this.state = {
            deliveryOption: 'Primary'
        } 
    }
    
    handleChange(e){
        this.setState({deliveryOption: e.target.value})
    }

    handleSubmit(e){
       e.preventDefault();
       this.props.updateFormData(this.state); 
    }

    render(){
        return(
            <div>
                <h1>Choose your delivery options here.
                    <form action="">
                        <input type="radio" checked={this.state.deliveryOption === "Primary"} value="Primary" /> Primary -- Next day delivery
                        <input type="radio" checked={this.state.deliveryOption === "Normal"} value="Normal" /> Normal -- 3 - 4 days
                        <input type="radio" checked={this.state.deliveryOption === "Primary"} value="Primary" /> Primary -- Next day delivery
                        <button type="submit">Submit</button>
                    </form>
                </h1>
            </div>
        )
    }
}
export default DeliveryDetails;